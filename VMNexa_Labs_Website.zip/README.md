# VMNexa Labs Website

A lightweight, responsive static website for VMNexa Labs.

## Files
- `index.html` — website content
- `styles.css` — responsive design
- `script.js` — mobile navigation and footer year
- `favicon.svg` — simple VMNexa favicon

## Free deployment: Cloudflare Pages
Cloudflare Pages supports static HTML sites and provides a `pages.dev` deployment URL. Static asset requests are free on the current Free plan.

1. Create/sign in to a Cloudflare account.
2. Create a Pages project and connect your Git repository, or use Direct Upload.
3. Upload this folder.
4. Keep `index.html` at the top level.
5. Deploy.

Official documentation:
https://developers.cloudflare.com/pages/framework-guides/deploy-anything/

## Before launch
1. Replace `hello@vmnexalabs.com` in `index.html` with the official company email.
2. Add the final company address, phone, social links, and legal/privacy pages if needed.
3. Replace any placeholder claims with verified company information.
4. Add a custom domain after you acquire one.

## Note
The site is intentionally framework-free so it can be hosted as a simple static site with no build step.
